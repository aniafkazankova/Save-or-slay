package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_plastic.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.lang.String


class MainActivity : AppCompatActivity() {
    val FILE_LEVEL = "file.txt"

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val kol: TextView = findViewById(R.id.kol)

        //saveText_b(kol, 0.1)
        //kol.setText("9.8")
        //saveText(kol)
        openText_b(kol)
        val plastik: Button=findViewById(R.id.plastik)
        plastik.setOnClickListener {
            val inten = Intent(this@MainActivity, plastic::class.java)
            startActivity(inten)
        }
        val metall: Button=findViewById(R.id.metall)
        metall.setOnClickListener {
            val inten = Intent(this@MainActivity, com.example.myapplication.metall::class.java)
            startActivity(inten)
        }
        val bouttle: Button=findViewById(R.id.bouttle)
        bouttle.setOnClickListener {
            val int = Intent(this@MainActivity, com.example.myapplication.bouttle::class.java)
            startActivity(int)
        }
        val clothers: Button=findViewById(R.id.clothers)
        clothers.setOnClickListener {
            val intt = Intent(this@MainActivity, com.example.myapplication.clothers::class.java)
            startActivity(intt)
        }
        val paper: Button=findViewById(R.id.paper)
        paper.setOnClickListener {
            val i = Intent(this@MainActivity, com.example.myapplication.paper::class.java)
            startActivity(i)
        }
        /*findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show()
        }*/
    }
    fun openText_b(view: View?) {
        var fin: FileInputStream? = null
        fin = openFileInput(FILE_LEVEL)
        val bytes = ByteArray(fin.available())
        fin.read(bytes)
        val text = String(bytes)
        kol.setText(text)

        fin?.close()
    }
    fun saveText(view: View?) {
        var fin: FileInputStream? = null
        fin = openFileInput(FILE_LEVEL)
        val bytes = ByteArray(fin.available())
        fin.read(bytes)
        val t = String(bytes)//данные из файла
        //t2 = t2.toString()//данные из TextView
        fin?.close()
        var fos: FileOutputStream? = null
        fos = openFileOutput(FILE_LEVEL, MODE_PRIVATE)
        //fos.write(((t.toDouble() + t2.toDouble()).toString()).toByteArray())
        fos?.close()
    }
    fun String.toDouble(): Double = java.lang.Double.parseDouble(this.toString())
}